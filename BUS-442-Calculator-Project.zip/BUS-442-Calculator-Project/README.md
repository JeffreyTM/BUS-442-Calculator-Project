# BUS-442-Calculator-Project

NC State University BUS 442 Major Project 2: Pair Coding Competition

Code Authors: Jeffrey Michaels and Will Shomo

All coding was done in Visual Studio in .NET Framework v4.7.2

This application is a calculator that has a set file of data points that can be evaluated with various statistical methods, such as the mean, range, standard deviation, etc. There is also a scientific calculator built in, which takes two inputs and evaluates various scientific methods, including factorial, reciprocal, prime, etc.
